{
    'name': 'Procyo Onboarding',
    'version': '1.0.0',
    'category': 'CRM',
    'summary': 'Stockage des réponses au questionnaire d\'onboarding Procyo',
    'author': 'Procyo',
    'depends': ['base', 'contacts'],
    'data': [
        'security/ir.model.access.csv',
        'views/procyo_onboarding_views.xml',
        'views/procyo_onboarding_menu.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
