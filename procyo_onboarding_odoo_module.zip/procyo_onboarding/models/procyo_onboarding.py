from odoo import models, fields, api

class ProcyoOnboarding(models.Model):
    _name = 'procyo.onboarding'
    _description = 'Questionnaire Onboarding Procyo'
    _rec_name = 'partner_id'
    _order = 'create_date desc'

    # ── Lien contact ──────────────────────────────────────────
    partner_id = fields.Many2one('res.partner', string='Courtier', required=True, ondelete='cascade')
    broker_email = fields.Char(string='Email webapp', help='Email utilisé lors de l\'inscription sur la webapp')

    # ── Statuts modules ───────────────────────────────────────
    module1_status = fields.Selection([
        ('active', 'Accessible'),
        ('completed', 'Clôturé'),
    ], string='Module 1', default='active')
    module2_status = fields.Selection([
        ('locked', 'Non disponible'),
        ('active', 'Accessible'),
        ('completed', 'Clôturé'),
    ], string='Module 2', default='locked')
    module3_status = fields.Selection([
        ('locked', 'Non disponible'),
        ('active', 'Accessible'),
        ('completed', 'Clôturé'),
    ], string='Module 3', default='locked')

    module1_completed_at = fields.Datetime(string='Module 1 clôturé le')
    module2_completed_at = fields.Datetime(string='Module 2 clôturé le')
    module3_completed_at = fields.Datetime(string='Module 3 clôturé le')
    last_reminder_at = fields.Datetime(string='Dernier rappel envoyé')

    # ── MODULE 1 — Section A : Identité ───────────────────────
    A1  = fields.Char('A1 - Raison sociale')
    A2  = fields.Char('A2 - Nom commercial')
    A3  = fields.Char('A3 - Numéro BCE/TVA')
    A4  = fields.Char('A4 - Numéro FSMA')
    A5  = fields.Char('A5 - Forme juridique')
    A6  = fields.Char('A6 - Adresse siège')
    A7  = fields.Text('A7 - Succursales')
    A8  = fields.Char('A8 - Téléphone')
    A9  = fields.Char('A9 - Email principal')
    A10 = fields.Char('A10 - Site web')
    A11 = fields.Text('A11 - Collaborateurs')
    A12 = fields.Char('A12 - Gestionnaire principal')
    A13 = fields.Char('A13 - DPO / RGPD')
    A14 = fields.Text('A14 - Horaires')
    A15 = fields.Char('A15 - Congés collectifs')

    # ── MODULE 1 — Section B : Signature & ton ───────────────
    B1  = fields.Text('B1 - Signature mail')
    B2  = fields.Char('B2 - Vouvoiement/Tutoiement')
    B3  = fields.Char('B3 - Ton')
    B4  = fields.Char('B4 - Niveau empathie sinistre')
    B5  = fields.Char('B5 - Formule politesse')
    B6  = fields.Char('B6 - Adresser le client par')
    B7  = fields.Char('B7 - Langue par défaut')
    B8  = fields.Char('B8 - Mention IA')
    B9  = fields.Text('B9 - Disclaimer RGPD')

    # ── MODULE 1 — Section C : Périmètre métier ──────────────
    C1  = fields.Text('C1 - Branches traitées')
    C2  = fields.Text('C2 - Branches exclues')
    C3  = fields.Char('C3 - Proportion PP/PM')
    C4  = fields.Text('C4 - Profils clients')
    C5  = fields.Char('C5 - Nb contrats actifs')
    C6  = fields.Char('C6 - Nb mails/jour')

    # ── MODULE 1 — Section D : Compagnies ────────────────────
    D1  = fields.Text('D1 - Compagnies mandats')
    D2  = fields.Text('D2 - Compagnie préférée par branche')
    D3  = fields.Text('D3 - Compagnies à éviter')
    D4  = fields.Char('D4 - Convention RDR')
    D5  = fields.Text('D5 - Délégation gestion sinistres')

    # ── MODULE 1 — Section E : Boîtes mail ───────────────────
    E1  = fields.Char('E1 - Email principal Inboxia')
    E2  = fields.Text('E2 - Emails secondaires')
    E3  = fields.Text('E3 - Mails à ne pas traiter')
    E4  = fields.Text('E4 - Catégories validation humaine')

    # ── MODULE 2 — Section F : Documentation ─────────────────
    F1  = fields.Char('F1 - CG produit')
    F2  = fields.Char('F2 - Conditions particulières')
    F3  = fields.Char('F3 - Délai CP')
    F4  = fields.Text('F4 - Types attestations')
    F5  = fields.Char('F5 - Délai attestation')
    F6  = fields.Char('F6 - IA pré-rédige attestation')

    # ── MODULE 2 — Section G : Devis ─────────────────────────
    G1  = fields.Text('G1 - Infos devis AUTO')
    G2  = fields.Text('G2 - Infos devis HABITATION')
    G3  = fields.Char('G3 - IA pose questions tarif')
    G4  = fields.Char('G4 - IA propose tarif')
    G5  = fields.Char('G5 - IA propose remise')
    G6  = fields.Char('G6 - Validité devis (jours)')

    # ── MODULE 2 — Section H : Modifications ─────────────────
    H1  = fields.Char('H1 - Changement adresse BRIO')
    H2  = fields.Char('H2 - Changement IBAN')
    H3  = fields.Char('H3 - Changement véhicule')
    H4  = fields.Char('H4 - Ajout conducteur')
    H5  = fields.Char('H5 - Changement formule effet')
    H6  = fields.Char('H6 - Changement formule validation')

    # ── MODULE 2 — Section I : Sinistres ─────────────────────
    I1  = fields.Text('I1 - Pièces sinistre AUTO')
    I2  = fields.Char('I2 - Mesures conservatoires')
    I3  = fields.Char('I3 - Délai 8 jours')
    I4  = fields.Text('I4 - Pièces sinistre HABITATION')
    I5  = fields.Char('I5 - Sinistre corporel IA')
    I6  = fields.Char('I6 - Alerte gestionnaire délai')

    # ── MODULE 2 — Section J : Suivi sinistres ───────────────
    J1  = fields.Char('J1 - IA liste intervenants')
    J2  = fields.Char('J2 - IA montants indemnisés')
    J3  = fields.Char('J3 - IA date clôture')
    J4  = fields.Char('J4 - IA annonce refus')
    J5  = fields.Char('J5 - Rétention résiliation')
    J6  = fields.Char('J6 - IA vérifie préavis')

    # ── MODULE 3 — Section K : Activités BRIO ────────────────
    K1  = fields.Text('K1 - Catégories activité BRIO')
    K2  = fields.Char('K2 - Type activité défaut')
    K3  = fields.Char('K3 - Destinataire activité')
    K4  = fields.Char('K4 - Priorité défaut')
    K5  = fields.Char('K5 - Délai échéance (jours)')
    K6  = fields.Char('K6 - Visible My Broker')

    # ── MODULE 3 — Section L : Documents BRIO ───────────────
    L1  = fields.Char('L1 - Entité classement défaut')
    L2  = fields.Text('L2 - Qualifiers BRIO')
    L3  = fields.Char('L3 - Constat → sinistre auto')
    L4  = fields.Char('L4 - Acte décès → sinistre vie')
    L5  = fields.Char('L5 - Acte mariage → mise à jour')

    # ── MODULE 3 — Section M : Procédures spéciales ──────────
    M1  = fields.Char('M1 - Alerte sinistre corporel canal')
    M2  = fields.Char('M2 - Mention recontact 24h')
    M3  = fields.Char('M3 - DPO RGPD')
    M4  = fields.Char('M4 - Procédure Ombudsman')
    M5  = fields.Char('M5 - Plainte qualité')
    M6  = fields.Char('M6 - Suspicion fraude')

    # ── MODULE 3 — Section N : Frontières IA ────────────────
    N1  = fields.Char('N1 - Brouillon sans validation')
    N2  = fields.Text('N2 - Modifications auto BRIO')
    N3  = fields.Char('N3 - Création sinistre auto')
    N4  = fields.Char('N4 - Classement document auto')
    N5  = fields.Char('N5 - Création activité auto')
    N6  = fields.Char('N6 - Montant max mention')
    N7  = fields.Char('N7 - Bloquer mail avocat')

    # ── MODULE 3 — Section O : Segmentation & monitoring ────
    O1  = fields.Char('O1 - Segmentation client')
    O2  = fields.Char('O2 - Comportement VIP')
    O3  = fields.Char('O3 - Relance auto')
    O4  = fields.Text('O4 - Délais relance')
    O5  = fields.Char('O5 - Rapport quotidien')
    O6  = fields.Char('O6 - Alerte mail sensible')
    O7  = fields.Char('O7 - Cross-sell dans brouillons')
    O8  = fields.Char('O8 - Détection gaps couverture')

    # ── Computed : progression ────────────────────────────────
    progress_m1 = fields.Float('Progression M1 (%)', compute='_compute_progress', store=True)
    progress_m2 = fields.Float('Progression M2 (%)', compute='_compute_progress', store=True)
    progress_m3 = fields.Float('Progression M3 (%)', compute='_compute_progress', store=True)

    @api.depends(
        'A1','A2','A3','A4','A5','A6','A7','A8','A9','A10','A11','A12','A13','A14','A15',
        'B1','B2','B3','B4','B5','B6','B7','B8','B9',
        'C1','C2','C3','C4','C5','C6',
        'D1','D2','D3','D4','D5',
        'E1','E2','E3','E4',
        'F1','F2','F3','F4','F5','F6',
        'G1','G2','G3','G4','G5','G6',
        'H1','H2','H3','H4','H5','H6',
        'I1','I2','I3','I4','I5','I6',
        'J1','J2','J3','J4','J5','J6',
        'K1','K2','K3','K4','K5','K6',
        'L1','L2','L3','L4','L5',
        'M1','M2','M3','M4','M5','M6',
        'N1','N2','N3','N4','N5','N6','N7',
        'O1','O2','O3','O4','O5','O6','O7','O8',
    )
    def _compute_progress(self):
        m1_fields = ['A1','A2','A3','A4','A5','A6','A7','A8','A9','A10','A11','A12','A13','A14','A15',
                     'B1','B2','B3','B4','B5','B6','B7','B8','B9',
                     'C1','C2','C3','C4','C5','C6',
                     'D1','D2','D3','D4','D5',
                     'E1','E2','E3','E4']
        m2_fields = ['F1','F2','F3','F4','F5','F6',
                     'G1','G2','G3','G4','G5','G6',
                     'H1','H2','H3','H4','H5','H6',
                     'I1','I2','I3','I4','I5','I6',
                     'J1','J2','J3','J4','J5','J6']
        m3_fields = ['K1','K2','K3','K4','K5','K6',
                     'L1','L2','L3','L4','L5',
                     'M1','M2','M3','M4','M5','M6',
                     'N1','N2','N3','N4','N5','N6','N7',
                     'O1','O2','O3','O4','O5','O6','O7','O8']
        for rec in self:
            def pct(flds):
                filled = sum(1 for f in flds if getattr(rec, f))
                return round(filled / len(flds) * 100, 1)
            rec.progress_m1 = pct(m1_fields)
            rec.progress_m2 = pct(m2_fields)
            rec.progress_m3 = pct(m3_fields)
